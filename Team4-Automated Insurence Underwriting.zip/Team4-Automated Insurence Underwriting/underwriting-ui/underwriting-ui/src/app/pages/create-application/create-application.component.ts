import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';

import { UnderwritingService } from '../../services/underwriting.service';

@Component({
  selector: 'app-create-application',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './create-application.component.html'
})
export class CreateApplicationComponent {

  form = {
    applicant: {
      name: '',
      age: 0,
      income: 0,
      occupation: '',
      location: '',
      prior_claims: 0,
      smoking_status: 'non-smoker'
    },
    product_type: 'Term Life',
    coverage_amount: 100000
  };

  constructor(
    private underwritingService: UnderwritingService,
    private router: Router
  ) {}

  create() {
    this.underwritingService.createApplication(this.form).subscribe({
      next: (res: any) => {
        console.log('Application created', res);
        this.router.navigate(['/run', res.id]);
      },
      error: (err: any) => {
        console.error('Create application failed', err);
      }
    });
  }
}
