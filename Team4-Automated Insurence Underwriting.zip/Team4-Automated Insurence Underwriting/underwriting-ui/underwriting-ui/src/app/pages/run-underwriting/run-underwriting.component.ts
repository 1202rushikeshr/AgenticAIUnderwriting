import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

import { UnderwritingService } from '../../services/underwriting.service';

@Component({
  selector: 'app-run-underwriting',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './run-underwriting.component.html'
})
export class RunUnderwritingComponent {

  applicationId = 0;
  documentText = '';

  constructor(
    private service: UnderwritingService,
    private router: Router
  ) {}

  run() {
    this.service.runUnderwriting(this.applicationId, this.documentText)
      .subscribe({
        next: (result: any) => {
          this.router.navigate(['/result', this.applicationId], {
            state: { result }
          });
        },
        error: (err: any) => {
          console.error('Underwriting failed', err);
        }
      });
  }
}
