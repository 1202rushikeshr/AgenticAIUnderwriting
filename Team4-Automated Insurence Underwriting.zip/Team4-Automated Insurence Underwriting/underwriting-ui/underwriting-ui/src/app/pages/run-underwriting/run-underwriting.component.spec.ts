import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RunUnderwritingComponent } from './run-underwriting.component';

describe('RunUnderwritingComponent', () => {
  let component: RunUnderwritingComponent;
  let fixture: ComponentFixture<RunUnderwritingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RunUnderwritingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RunUnderwritingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
