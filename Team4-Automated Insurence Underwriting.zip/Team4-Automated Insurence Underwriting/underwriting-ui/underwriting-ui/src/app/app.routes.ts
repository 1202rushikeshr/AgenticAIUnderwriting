// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { CreateApplicationComponent } from './pages/create-application/create-application.component';
import { RunUnderwritingComponent } from './pages/run-underwriting/run-underwriting.component';
import { ResultComponent } from './pages/result/result.component';

export const routes: Routes = [
  // Default: go straight to create page
  { path: '', component: CreateApplicationComponent },

  { path: 'create', component: CreateApplicationComponent },
  { path: 'run/:id', component: RunUnderwritingComponent },
  { path: 'result/:id', component: ResultComponent },

  // Wildcard – in case of typo, send back to create
  { path: '**', redirectTo: 'create' }
];
