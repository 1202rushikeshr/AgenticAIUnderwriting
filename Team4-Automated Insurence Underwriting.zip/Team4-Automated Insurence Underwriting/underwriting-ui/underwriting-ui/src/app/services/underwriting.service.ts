import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UnderwritingService {

  private baseUrl = 'http://127.0.0.1:8000';

  constructor(private http: HttpClient) {}

  /** CREATE APPLICATION */
  createApplication(payload: any): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/api/applications/`,
      payload
    );
  }

  /** RUN UNDERWRITING */
  runUnderwriting(applicationId: number, documentText: string): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/ai-underwriting/run/${applicationId}`,
      { document_text: documentText }
    );
  }
}
